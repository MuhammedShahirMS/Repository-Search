import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import SearchPage from './Pages/SearchPage';
import NavigationBar from './components/Navbar';

function App() {


  return (
    <>
      <NavigationBar/>
      <SearchPage/>
    </>
  )
}

export default App
