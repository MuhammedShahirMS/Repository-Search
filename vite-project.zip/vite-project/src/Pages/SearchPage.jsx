import { useRef, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Table from 'react-bootstrap/Table';
import Container from 'react-bootstrap/Container';


const SearchPage = () => {

const [results, setResults] = useState([])


const searchInput = useRef()

const tableRows = results.map((info, index) => {
    return (
      <tr>
        <td>{index+1}</td>
        <td>{info.name}</td>
        <td>{info.created_at.split('T')[0]}</td>
        <td>{info.default_branch}</td>
      </tr>
    );
  });


const searchRepository = async () => {
    const searchText = searchInput.current.value
    if(searchText.trim().length === 0){
        alert('Enter some text')
        return
    }

    try{
        const response = await fetch(`https://api.github.com/search/repositories?q=${searchText}`)
    
        const data = await response.json()
        console.log('Fetched Repositories are', data)

        if(data){
            setResults(data.items)
        }
    } catch(error)
    {
        alert('Failed to fetch')
    }
    
   
    

    //const response = await fetch(`https://docs.github.com/en/rest/search?${searchText}`)
    
    
}

    return (

        <Container className='mt-5'>
        <InputGroup className="mb-3">
        <Form.Control
          placeholder="Search Repository"
          aria-label="Recipient's username"
          aria-describedby="basic-addon2"
          ref={searchInput}
        />
        <Button onClick={searchRepository} variant="outline-secondary" id="button-addon2">
          Search
        </Button>
      </InputGroup>
        {results.length ? <Table striped bordered hover variant="dark">
        <thead>
          <tr>
            <th>Sr.NO</th>
            <th>Name</th>
            <th>Created at</th>
            <th>Default Branch</th>
          </tr>
        </thead>
        <tbody>{tableRows}</tbody>
        
         
    </Table> : ''}
    </Container>
        
    )


}

export default SearchPage
